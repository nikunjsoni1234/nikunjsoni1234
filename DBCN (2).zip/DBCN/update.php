<?php
     session_start();
    //print_r($_SESSION);
    include 'dbcn.php';
    
    $sql="SELECT * FROM `register` where id='".$_SESSION["id"]."'";
    $resul=$conn->query($sql);
    if($resul->num_rows > 0)
    {
      while($row = $resul->fetch_assoc()) 
      {
         $id = $row["id"];
         $username = $row["username"];
         $eml = $row["email"];
         $phone = $row["phone"];
         $password = $row["password"];
         $_SESSION["photo"]=$row["photo"];
      }
    
    }
    
    
    if(isset($_POST["sub"]))
    {
        
        $nm=$_POST["nm"];
        $email=$_POST["em"];
        $ph=$_POST["ph"];
        $pass=$_POST["pass"];
        
     //   $fnm=$_POST["file-upload"];

        
      //upload profile photo
        print_r($_FILES);
        $tmp_name=$_FILES["file-upload"]["tmp_name"];
        $type=$_FILES["file-upload"]["type"];    
        $size=$_FILES["file-upload"]["size"]/1024;    
        $path="updatedprofile/".$_FILES["file-upload"]["name"];
        //$_SESSION["photo"]=$path;
        //move_uploaded_file($tmp_name,$path);
        
            $photo=$path;
        
       
        //updating information
        // if (move_uploaded_file($tmp_name, $path))  
        // {
        //     echo "Image uploaded successfully.<br>";
        
        include 'dbcn.php';
        $result="UPDATE `register` SET  username='$nm',  email='$email',phone='$ph', password='$pass' , photo='$photo' WHERE id='".$_SESSION["id"]."'";
        //echo $result;
        $sql=$conn->query($result);
        $_SESSION["photo"]=$photo;
      //  $_SESSION["password"]=$pas;
        //}
        //else{
            //echo "failed to upload image";
        //}
        
        if($sql==TRUE)
        {
            
            
            header("update.php"); 
            $a="successful updation";
             
          
        }    
        
    }
    //deleting profile picture
    if(isset($_POST["del"]))
        {
            
            include 'dbcn.php';
          //  $sql = "UPDATE register SET photo=''  WHERE id='".$_SESSION["id"]."'" ;

            //$a=$conn->query($sql); 
        // {
           
        //     header("location:update.php");
        //     echo "Record deleted successfully";
        //     //session_destroy();
        // } 
        // else 
        // {
        //     echo "Error deleting record: " . $conn->error;
        // }
        //     // $del="DELETE FROM `register` WHERE `id` = '".$_SESSION["id"]."'";
        //     // $sql=$conn->query($del);
        //     // if($sql==TRUE)
        //     // {
        //     //     echo " deleted";
        //     // }
        // }    
        }
?>
<body>
    <center>
        <form method="post"enctype="multipart/form-data">
        <div classname="form">
            <h1>Update Account</h1>
            <?php error_reporting(0); echo "<h1>$a</h1>";?><br><br>
        <label>Enter new Username :</label>
        <input type="text" name="nm" value="<?php echo  $username?>"required ><br><br>

        <label>Enter new E-mail :</label>
        <input type="email" name="em" value="<?php echo $eml ?>"  required><br><br>
        
        <label>Enter new phone :</label>
        <input type="number" name="ph" value="<?php echo $phone ?>" required><br><br>
        
        <label>Enter new Password :</label>
        <input type="password" name="pass" value="<?php echo $password ?>"><br><br>

        <input type="file" name="file-upload"><br><br>
        <img src="<?php  echo $_SESSION["photo"] ; ?>" alt="img" width="150px" height="150px"><input type="submit" name="del" value="Delete">
        

        <h2><input type="submit" name="sub" value="Update"><h2>
        


        <h1>don't have any updation <a href="welcome.php">click here</a></h1>
        </div>
        </form>
    </center>
</body>