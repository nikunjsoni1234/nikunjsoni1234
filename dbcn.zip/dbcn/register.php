<?php
    
    session_start();
    if(isset($_POST["sub"]))
    {
        $nm=$_POST["nm"];
        $em=$_POST["em"];
        $ph=$_POST["ph"];
        $pass=$_POST["pass"];
        $pas=base64_encode($pass);
        
        include 'dbcn.php';
    
        if(!$conn)
        {
            die('Could not Connect My Sql:' .mysql_error());
        }
    
        $sql="SELECT * FROM `register` WHERE `email`='".$em."'";
        $result1=$conn->query($sql);
        
        if($result1->num_rows > 0)
        {                                                                                              
          while($row = $result1->fetch_assoc()) 
          {
            $a=" Email is already existed";
          }
        }

        
        $result="INSERT INTO `register`(`username`, `email`, `phone`, `password`) VALUES ('$nm','$em','$ph','$pas')";
        $sql=$conn->query($result);
        
        if($sql==TRUE)
        {
            echo "Registration Successful";
           header("location:login.php ");
        }
        
    }

?>
<body>
    <center>
        <form method="post">
        <div classname="form">
            <h1>Create Account</h1>
        <label>Enter Username :</label>
        <input type="text" name="nm" placeholder="Enter name*" required><br><br>

        <label>Enter E-mail :</label>
        <input type="email" name="em" placeholder="Enter email*"  required><?php error_reporting(0); echo $a;?><br><br>
        
        <label>Enter phone :</label>
        <input type="number" name="ph" placeholder="Enter phone no.*" required><br><br>
        
        <label>Enter Password :</label>
        <input type="password" name="pass" placeholder="Enter password*" required><br><br>

        <h2><input type="submit" name="sub" value="Signin"><h2>

        <h1>have an account<a href="login.php">Login Here</a></h1>
        </div>
        </form>
    </center>
</body>