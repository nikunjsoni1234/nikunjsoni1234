<?php
     session_start();
    //print_r($_SESSION);
    
    include 'dbcn.php';
    
    $sql="SELECT `id`,`email`,`username`,`phone`,`password` FROM `register` where id='".$_SESSION["id"]."'";
    $resul=$conn->query($sql);
    if($resul->num_rows > 0)
    {
      while($row = $resul->fetch_assoc()) 
      {
         $_SESSION["id"] = $row["id"];
         $_SESSION["email"] = $row["email"];
         $_SESSION["username"] = $row["username"];
         $_SESSION["phone"] = $row["phone"];
         $_SESSION["password"] = $row["password"];
       
      }
    
    }
    if(isset($_POST["sub"]))
    {
        $nm=$_POST["nm"];
        $email=$_POST["em"];
        $ph=$_POST["ph"];
        $pass=$_POST["pass"];
        $pas=base64_encode($pass);
        
        include 'dbcn.php';
        $result="UPDATE `register` SET  username='$nm',  email='$email',phone='$ph', password='$pas' WHERE id='".$_SESSION["id"]."'";
        $sql=$conn->query($result);
        
        if($sql==TRUE)
        {
            header("location:welcome.php");
          
        }
        $filename = $_FILES["uploadfile"]["name"];
        $tempname = $_FILES["uploadfile"]["tmp_name"];    
            $folder = "image/".$filename;
        $query="INSERT INTO `register` VALUES ('$filename')";        
    }

    
?>
<body>
    <center>
        <form method="post">
        <div classname="form">
            <h1>Update Account</h1>
        <label>Enter new Username :</label>
        <input type="text" name="nm" value="<?php echo  $_SESSION["username"]?>" required><br><br>

        <label>Enter new E-mail :</label>
        <input type="email" name="em" value="<?php echo $_SESSION["email"] ?>"  required><br><br>
        
        <label>Enter new phone :</label>
        <input type="number" name="ph" value="<?php echo $_SESSION["phone"] ?>" required><br><br>
        
        <label>Enter new Password :</label>
        <input type="password" name="pass" value="<?php echo $_SESSION["password"] ?>" required><br><br>

        <input type="file" name="file-upload"  ><br><br>

        <h2><input type="submit" name="sub" value="Update"><h2>

        <h1>don't have any updation<a href="welcome.php">click here</a></h1>
        </div>
        </form>
    </center>
</body>