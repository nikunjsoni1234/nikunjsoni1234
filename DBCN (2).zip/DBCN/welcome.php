<?php
    session_start();

    print_r("welcome".$_SESSION["username"]);
    include "dbcn.php";
    $sql="SELECT * FROM `register` where id='".$_SESSION["id"]."'";
    $resul=$conn->query($sql);
    if($resul->num_rows > 0)
    {
      while($row = $resul->fetch_assoc()) 
      {
        $photo=$row["photo"];
      }
    }
       
    if(isset($_POST['edit']))
    {
               header("location:update.php");
    }

    if(!isset($_SESSION['id']))
    {
        session_destroy();
       header("location:login.php",'refresh:5');
    }
    
    if(isset($_POST['sub']))
    {
        session_destroy();
        header("location:login.php",'refresh:5');
    }
    
    
?>


<body>
    <br><br><img src="<?php echo $photo; ?>" alt="img" width="150px" height="150px">
    <center>
            <form method = "post">
                <input type="submit" name="sub" value="logout">
                <input type="submit" name="edit" value="edit-your profile"> 
                
               
            </form>
    </center>
</body>