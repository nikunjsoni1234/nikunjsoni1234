<?php
    
    session_start();
    if(isset($_POST["sub"]))
    {
        $em=$_POST["em"];
        $pass=$_POST["pass"];
        $pas=base64_encode($pass);
        include 'dbcn.php';
        
        $sql="SELECT     `id`,`email` `password` FROM `register` WHERE `email`='".$em."' and `password` = '".$pas."' ";
        $result=$conn->query($sql);
        
     
  
        if($result->num_rows > 0)
        {
          while($row = $result->fetch_assoc()) 
          {
            echo $_SESSION["id"] = $row["id"];
            echo $_SESSION["email"] = $row["email"];
            header("location:update.php");
          }
        }
      
        else
        {
              echo"data not found";
        }
    }
    
?>

<body>
    <center>
        <form method="post">
        <div classname="form">
            <h1>LOGIN</h1>
        <label>Enter E-mail :</label>
        <input type="email" name="em" placeholder="Enter E-mail*" required><br><br>
        
        <label>Enter Pasword :</label>
        <input type="password" name="pass" placeholder="Enter password*" required><br><br>

        

        <h2><input type="submit" name="sub" value="Login"><h2>

        <h1> Don't have an account<a href="register.php">Register Here</a></h1>
        </div>
        </form>
    </center>
</body>