<?php
    
    session_start();
    // if(isset($_POST["login"]))
    // {
    //     $em=$_POST["em"];
    //     $pass=$_POST["pass"];
        
    //     include 'dbcn.php';
        
    //     $sql="SELECT * FROM `register` WHERE `email`='".$em."' and `password` = '".$pass."' ";
    //     $result=$conn->query($sql);
        
     
  
    //     if($result->num_rows > 0)
    //     {
    //       while($row = $result->fetch_assoc()) 
    //       {
    //         echo $_SESSION["id"] = $row["id"];
    //         //echo $_SESSION["username"] = $row["username"];
    //        // echo $_SESSION["email"] = $row["email"];
    //        // echo $_SESSION["password"]=$row["password"];
    //         //echo $_SESSION["photo"]=$row["photo"];
    //         header("location:welcome.php");
    //       }
    //     }
    // }
    // else
    // {
    //     echo"data not found";
    // }
    if(isset($_POST["sub"]))
    {
        $em=$_POST["em"];
        $pss=$_POST["pass"];
        
        include 'dbcn.php';
        
        $sql="SELECT * FROM `register` WHERE `email`='".$em."' and `password` = '".$pss."' ";
        $result=$conn->query($sql);
        
     
  
        if($result->num_rows > 0)
        {
          while($row = $result->fetch_assoc()) 
          {
            echo $_SESSION["id"] = $row["id"];
            echo $_SESSION["username"] = $row["username"];
            // echo $_SESSION["email"] = $row["email"];
            // echo $_SESSION["password"]=$row["password"];
            // echo $_SESSION["photo"]=$row["photo"];
            header("location:update.php");
          }
        }
      
        else
        {
              echo"data not found";
        }
    }
    
?>

<body>
    <center>
        <form method="post">
        <div classname="form">
            <h1>LOGIN</h1>
        <label>Enter E-mail :</label>
        <input type="email" name="em" placeholder="Enter E-mail*" required><br><br>
        
        <label>Enter Pasword :</label>
        <input type="password" name="pass" placeholder="Enter password*" required><br><br><br>

        <input type="submit" name="sub" value="update-Profile">
        <input type="submit" name="login" value="login">

        <h1> Don't have an account<a href="register.php">Register Here</a></h1>
        
        </div>
        </form>
    </center>
</body>