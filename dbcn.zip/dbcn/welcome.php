<?php
    session_start();
    print_r($_SESSION);
    if(!isset($_SESSION['id']))
    {
        session_destroy();
       header("location:login.php",'refresh:5');
    }
    if(isset($_POST['sub']))
    {
        session_destroy();
        header("location:login.php",'refresh:5');
    }
    
?>


<body>
    <center>
            <form method = "post">
                <input type="submit" name="sub" value="logout">
               
            </form>
    </center>
</body>